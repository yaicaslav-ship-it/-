package com.example.mentionsound;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.authlib.GameProfile;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.network.message.MessageType;
import net.minecraft.network.message.SignedMessage;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MentionSoundClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("mentionsound");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Config file: .minecraft/config/mentionsound/config.json */
    public static class Config {
        /** Extra names/words that trigger the sound (your own nick is always included). */
        public List<String> extraNames = new ArrayList<>();
        /** File name inside config/mentionsound/. Supported: WAV, AIFF, AU. */
        public String soundFile = "sound.wav";
        /** 0.0 - 1.0 */
        public float volume = 1.0f;
        /** Do not play when you wrote the message yourself. */
        public boolean ignoreOwnMessages = true;
        /** Play a vanilla sound if the custom file is missing or broken. */
        public boolean fallbackToVanillaSound = true;
        /** Minimum delay between sounds, ms. */
        public long cooldownMs = 500;
    }

    private static Config config = new Config();
    private static Path configDir;
    private static long lastPlayed = 0;

    @Override
    public void onInitializeClient() {
        configDir = FabricLoader.getInstance().getConfigDir().resolve("mentionsound");
        loadConfig();

        // Normal player chat
        ClientReceiveMessageEvents.CHAT.register(
                (Text message, SignedMessage signed, GameProfile sender,
                 MessageType.Parameters params, Instant timestamp) -> {
                    String own = ownName();
                    boolean isOwn = sender != null && sender.getName().equalsIgnoreCase(own);
                    handle(message.getString(), isOwn);
                });

        // Server-formatted chat (plugins, Paper, etc.) arrives as "game" messages
        ClientReceiveMessageEvents.GAME.register((Text message, boolean overlay) -> {
            if (overlay) return;
            String text = message.getString();
            String own = ownName().toLowerCase(Locale.ROOT);
            String low = text.toLowerCase(Locale.ROOT);
            // Simple heuristic for "<Nick> hi" or "Nick: hi" or "Nick » hi"
            boolean isOwn = low.startsWith("<" + own + ">")
                    || low.startsWith(own + ":")
                    || low.startsWith(own + " »")
                    || low.startsWith(own + " >");
            handle(text, isOwn);
        });

        LOGGER.info("Mention Sound loaded. Put your sound at {}", configDir.resolve(config.soundFile));
    }

    private static String ownName() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.getSession().getUsername();
    }

    private static void handle(String text, boolean isOwn) {
        if (isOwn && config.ignoreOwnMessages) return;

        String low = text.toLowerCase(Locale.ROOT);
        List<String> names = new ArrayList<>(config.extraNames);
        names.add(ownName());

        boolean mentioned = false;
        for (String n : names) {
            if (n != null && !n.isBlank() && low.contains(n.toLowerCase(Locale.ROOT))) {
                mentioned = true;
                break;
            }
        }
        if (!mentioned) return;

        long now = System.currentTimeMillis();
        if (now - lastPlayed < config.cooldownMs) return;
        lastPlayed = now;

        playSound();
    }

    private static void playSound() {
        Path file = configDir.resolve(config.soundFile);
        if (Files.exists(file)) {
            Thread t = new Thread(() -> {
                try {
                    playFile(file);
                } catch (Exception e) {
                    LOGGER.warn("Could not play {}: {} (use WAV/AIFF/AU)", file, e.toString());
                    if (config.fallbackToVanillaSound) playVanilla();
                }
            }, "MentionSound-Player");
            t.setDaemon(true);
            t.start();
        } else if (config.fallbackToVanillaSound) {
            playVanilla();
        }
    }

    private static void playFile(Path file) throws Exception {
        try (AudioInputStream in = AudioSystem.getAudioInputStream(file.toFile())) {
            Clip clip = AudioSystem.getClip();
            clip.open(in);
            if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                float v = Math.max(0.0001f, Math.min(1.0f, config.volume));
                float db = (float) (20.0 * Math.log10(v));
                gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), db)));
            }
            clip.addLineListener(ev -> {
                if (ev.getType() == LineEvent.Type.STOP) clip.close();
            });
            clip.start();
        }
    }

    private static void playVanilla() {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> mc.getSoundManager().play(
                PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_PLING, 1.0f, config.volume)));
    }

    private static void loadConfig() {
        try {
            Files.createDirectories(configDir);
            Path cfg = configDir.resolve("config.json");
            if (Files.exists(cfg)) {
                try (Reader r = Files.newBufferedReader(cfg)) {
                    Config loaded = GSON.fromJson(r, Config.class);
                    if (loaded != null) config = loaded;
                }
            }
            // always rewrite so new fields appear
            try (Writer w = Files.newBufferedWriter(cfg)) {
                GSON.toJson(config, w);
            }
        } catch (IOException e) {
            LOGGER.error("Config error", e);
        }
    }
}
