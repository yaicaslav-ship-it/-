# Mention Sound (Fabric 1.21.4)

Client-side mod: plays a sound when your nickname is mentioned in chat.

## Build
Requires JDK 21. Add the Gradle wrapper (copy gradlew, gradlew.bat and /gradle from
https://github.com/FabricMC/fabric-example-mod) or use an installed Gradle 8.12+:

    gradle build

Jar: build/libs/mentionsound-1.0.0.jar -> put into .minecraft/mods (needs Fabric API).

## Your own sound
Put a WAV file here: .minecraft/config/mentionsound/sound.wav
(WAV / AIFF / AU are supported; OGG/MP3 are not - convert them to WAV.)
Settings: .minecraft/config/mentionsound/config.json
